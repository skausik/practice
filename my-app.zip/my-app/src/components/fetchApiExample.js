import "./styles.css";
import React, { useState, useEffect } from "react";

export default function App() {
  let url = "https://my-json-server.typicode.com/pranaynailwal/todo-list/db";
  const [data, setData] = useState();
  useEffect(() => {
    fetch(url)
      .then((res) => res.json())
      .then((data) => setData(data));
  }, [url]);
  console.log("data", data);
  const obj = data;

  let value = Object.values(obj);

  value.map((a) =>
    a.map((b) => {
      return console.log("todo", b.name);
    })
  );

  return (
    <div className="App">
      {/* {console.log("ddd", data)} */}

      <h1>Hello CodeSandbox </h1>
      <h2>Start editing to see some magic happen!</h2>
    </div>
  );
}
