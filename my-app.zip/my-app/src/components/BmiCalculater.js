import React, { useState } from "react";

const BmiCalculater = () => {
  let [waight, setWaight] = useState();
  let [height, setHeight] = useState();
  let [age, setAge] = useState();
  let [bmi, setBmi] = useState();

  const calculateBMI = () => {
    if (
      waight !== null ||
      (waight !== undefined && height !== null) ||
      height !== undefined
    ) {
      bmi = waight / height;
      setBmi(bmi);
      console.log("bmi", bmi);
    //   if (bmi >= 25) alert("A BMI of 25.0 or more is overweight");
    //   else if (bmi >= 18.5 && bmi <= 24.9)
    //     alert("the healthy range is 18.5 to 24.9");
    //   else if (
    //     bmi === 18 ||
    //     bmi === 19 ||
    //     bmi === 20 ||
    //     bmi === 21 ||
    //     bmi === 22 ||
    //     bmi === 23 ||
    //     bmi === 24 ||
    //     bmi === 25
    //   )
    //     alert("Your BMI is healthy and normal");
    //   else if (age <= 10 && age >= 5 && bmi <= 19 && bmi >= 18)
    //     alert("Your BMI is healthy");
    } else alert("Please fill the mandatory fields");
    return bmi;
  };

  return (
    <>
    <div className="w-full items-center justify-center">
      <div className="flex flex-col space-y-2 p-4 pb-4 m-4 border-2 rounded-lg border-pink-600 w-1/3 items-center justify-center">
        <span className="pt-4 text-2xl h-12 border-b border-pink-800 text-pink-800 font-medium">
          BMI Calculator
        </span>
        <span className="pt-4 text-lg text-pink-800 font-medium">
          Enter Waight *
        </span>
        <input
          className="h-12 border-2 rounded-lg border-pink-600 w-full text-black px-2"
          type="number"
          id="waight"
          value={waight}
          onChange={(e) => {
            setWaight(e.target.value);
          }}
        />
        <span className="pt-4 text-lg text-pink-800 font-medium">
          Enter Height *
        </span>
        <input
          className="h-12 border-2 rounded-lg border-pink-600 w-full text-black px-2 mb-4"
          type="number"
          id="age"
          value={height}
          onChange={(e) => {
            setHeight(e.target.value);
          }}
        />
        <span className="pt-4 text-lg text-pink-800 font-medium">
          Enter Age
        </span>
        <input
          className="h-12 border-2 rounded-lg border-pink-600 w-full text-black px-2 mb-4"
          type="number"
          id="height"
          value={age}
          onChange={(e) => {
            setAge(e.target.value);
          }}
        />
        <button
          className="py-2 border-2 bg-pink-600 rounded-lg border-pink-800 w-full text-white px-2 mt-4"
          onClick={() => calculateBMI()}
        >
          Calculate BMI
        </button>
        <div className="py-4">
          {bmi !== null ? <span>BMI is : {bmi}</span> : <></>}
          <div className="flex flex-col items-center justify-center text-green-600 font-medium space-y-2">
          {bmi <= 25 && <span>A BMI of 25.0 or less is underWeight</span>}
            {bmi >= 25 && <span>A BMI of 25.0 or more is overweight</span>}
            {bmi >= 18.5 && bmi <= 24.9 && (
              <span>the healthy range is 18.5 to 24.9</span>
            )}

            {(bmi === 18 ||
              bmi === 19 ||
              bmi === 20 ||
              bmi === 21 ||
              bmi === 22 ||
              bmi === 23 ||
              bmi === 24 ||
              bmi === 25) && <span>Your BMI is healthy and normal</span>}
            {age <= 10 && age >= 5 && bmi <= 19 && bmi >= 18 && (
              <span>Your BMI is healthy</span>
            )}
          </div>
        </div>
      </div>
      </div>
    </>
  );
};

export default BmiCalculater;
