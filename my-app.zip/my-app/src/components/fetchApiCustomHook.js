import React, { useState, useEffect } from "react";
const url = "/go/do/fetchCorrectApi/FeatchProcess";
const useFetchApi = (url) => {
  cont[(data, setData)] = useState();
  useEffect(() => {
    fetch(url)
      .then((res) => res.json())
      .then((data) => setData(data));
  }, [url]);
  return [data];
};
export default useFetchApi;
