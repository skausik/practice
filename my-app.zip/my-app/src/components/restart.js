import React from "react";
import { useState } from "react";

var Restart = () => {
  let [value, setValue] = useState();
  let [result, setResult]=useState();
  return (
    <>
      <div className="bg-green-800 w-full h-full content-center flex flex-col items-center justify-center">
        <div className="bg-yellow-400 text-orange-500 text-lg w-1/2 content-center">
          Restart my React Jurney again, Please help me vogoban; om Vignaharta
          Ganashai namo.
        </div>
        <div>
          <input
            className="h-12 mb-20"
            value={value}
            id="one"
            onChange={(e)=>{setValue(e.target.value ||'')}}
          />
          <div className="text-green-700">Value is here: {result}</div>
          <button
            className="w-full bg-pink-800 rounded-full"
            onClick={()=>setResult(value)}
          >
            Click here
          </button>
        </div>
      </div>
    </>
  );
};

export default Restart;
