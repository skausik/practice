import React from "react";
import ClassComEx1 from "./ClassComEx1";
// import BmiCalculater from "./BmiCalculater";
// import Restart from "./restart";
// import JScodePractice from "./JScodePractice";
// import UseStateHook from "./reactHooks/useStateHook";
//import UseEffectHook from './reactHooks/useEffectHook';
//import TestJavaScript from './reactHooks/testJavaScript';
//import ReadJsonFile from "./ReadJsonFile";

import JSCodePractice1 from "./JScodePractice1";

let Index = () => {
  return <>
  <div className="m-4 border-4 border-black h-screen ">
  {/* <JScodePractice/> */}
  {/* <UseStateHook/> */}
  {/* <UseEffectHook /> */}
{/* <TestJavaScript/> */}
{/* <ReadJsonFile/> */}

{/* <BmiCalculater/> */}
{/* <Restart/> */}
{/* <JSCodePractice1/> */}
<ClassComEx1 age={18}/>
  </div>
  </>;
};

export default Index;
