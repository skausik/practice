import React from "react";
import { useSelector, useDispatch } from "react-redux";
import { incNumber, decNumber } from "./actions";

const ReactRedux = () => {
  const myState = useSelector((state) => state.changeTheNumber);
  const abc = useDispatch();
  return (
    <>
      <div className="mt-8">
        <div className="font-bold text-4xl py-16">Welcome to React Redux</div>
        <div className="flex flex-row space-x-4 items-center justify-center m-4 border-2 border-pink-700 mx-64 py-16">
          <button
            onClick={() => abc(incNumber())}
            className="w-16 h-16 border text-white text-xl font-bold rounded-lg bg-sky-800 pb-1"
          >
            +
          </button>
          <div className="w-16 h-16 border text-white text-xl font-bold rounded-lg bg-pink-800 pt-4">
            {myState}
          </div>
          <button
            onClick={() => {
            //   return {
              // console.log("Hiii");
              abc(decNumber())
             // }
              
            }}
            className="w-16 h-16 border text-white text-xl font-bold rounded-lg bg-sky-800 pb-1"
          >
            -
          </button>
        </div>
      </div>
    </>
  );
};

export default ReactRedux;
