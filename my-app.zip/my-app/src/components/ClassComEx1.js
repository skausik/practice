import React, { Component } from 'react'

export class ClassComEx1 extends Component {

  constructor(props) {
    super(props)
  
    this.state = {
       count:0,
       name:"kausik",
       message:"Good Morning!"
    }
  }

  handleIncriment=()=>{
    this.setState({
      count:this.state.count +1,
      message:"Welcome!"
    })
    console.log(this);
  }

componentDidMount=()=>{
  console.log();
}
  
  
  render() {
    const {count, name,message}=this.state
    return (
      <div>
        <h1>{message}</h1>
        <button onClick={this.handleIncriment.bind(this)}>Click {count} {this.props.age}</button>
      </div>
    )
  }
}

export default ClassComEx1
