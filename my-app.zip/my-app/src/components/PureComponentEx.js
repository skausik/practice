import React, { PureComponent } from 'react'
import PropTypes from 'prop-types'
//rpcp
export default class PureComponentEx extends PureComponent {
  static propTypes = {

  }

  render() {
    //check shellow comparison on the props ans state
    console.log("pureComponent");
    return (
      <div>
        
      </div>
    )
  }
}
