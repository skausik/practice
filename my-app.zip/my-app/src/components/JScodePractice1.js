let JSCodePractice1 = () => {
  // var arr=[1,2,3,4,5];

  // arr.push(6);
  // arr.pop();
  //  arr.slice(1,3);
  // console.log("output :",arr);

  // slice()
  // slice(start)
  // slice(start, end)
  //const fruits = ["Banana", "Orange", "Lemon", "Apple", "Mango"];
  // const citrus = fruits.slice(1, 3);
  // console.log(citrus);
  // const myBest = fruits.slice(-3, -1);
  // console.log(myBest);
  // Create an Array

  // const fruits = ["Banana", "Orange", "Apple", "Mango"];
  // // At position 2, add "Lemon" and "Kiwi":
  // fruits.splice(0, 1, "Lemon", "Kiwi");
  // console.log(fruits);
  // splice(start)
  // splice(start, deleteCount)
  // splice(start, deleteCount, item1)
  // splice(start, deleteCount, item1, item2)
  // splice(start, deleteCount, item1, item2, /* …, */ itemN)

  //CODING QUESTIONS--------------------------------------------------------------------------------------------------------------
  // 1.Write a JavaScript function to calculate the sum of two numbers.
        // let sum=(a,b)=>a+b;
        // console.log(sum(2,3));

  // 2. Write a JavaScript program to find the maximum number in an array.

        // function maxNumber(arr) {
        //     var maxNum = arr[0];
        //     for (let i = 1; i < arr.length; i++) {
        //     // console.log(arr[i]);
        //     if (arr[i] > maxNum) {
        //         maxNum = arr[i];
        //     }
        //     }
        //     return maxNum;
        // }
        // console.log(maxNumber([1, 33, 50, 100, 67, 13, 102]));


  // 3. Write a JavaScript program to find 3 lergest  number in an array.

        // function lergestThreeElm(arr) {
        //     let sortedArray= arr.sort((a,b)=> b - a);
        //     let [first, second, third] = sortedArray.slice(0,3);
        //     return {
        //         first, second, third
        //     };
        // }
        // console.log(lergestThreeElm([1,2,3,4,5]));

// 3. Write a JavaScript function to check if a given string is a palindrome (reads the same forwards and backwards). 

    function checkPalindrome(inputStr) {
        return  inputStr.split();
   
    }

    console.log(checkPalindrome("romfff"));






















};
export default JSCodePractice1;
