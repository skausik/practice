import React, { useState } from "react";

let UseStateHook = () => {
  const [count, setCount] = useState(0);
  return (
    <>
     <div className="text-3xl font-bold py-6">Example of useState Hook</div>
      <div className="flex flex-col items-center justify-center ">
       <div className=" w-48 border-2 p-4 m-4">
        <div className=" bg-sky-500 m-4 p-4 text-white">{count}</div>
        <div className="flex flex-row items-center justify-center">
          <button
            className={`flex flex-col items-center justify-center p-4 h-12 w-32 border-2 rounded-lg bg-black text-white my-4`}
            onClick={() => {
              setCount(count + 1);
            }}
          >
            Click me
          </button>
        </div>
        </div>
      </div>
    </>
  );
};

export default UseStateHook;
