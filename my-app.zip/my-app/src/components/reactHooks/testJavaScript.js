import React, { useState } from "react";

const TestJavaScript = () => {
  let [value, setValue] = useState(10);

  console.log(value);

  const employee = [
    {
      name: "a",
      location: "bangalore",
    },
    {
      name: "b",
      location: "kolkata",
    },
    {
      name: "c",
      location: "jhargram",
    },
  ];

  const employeelist = employee.filter((a)=>a.location==="bangalore");

  console.log(employeelist);

  // const chieldComponent = ({ value }) => {
  //   return <div>{value}</div>;
  // };

  // return(<div>{value}</div>)
};

export default TestJavaScript;
