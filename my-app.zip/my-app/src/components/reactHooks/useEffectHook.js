import React, { useEffect, useState } from "react";
//useEffect runs on every render
//This is the Lifecycle hook of react functionmal component
//React Hooks provides a special Hook, useEffect() to execute certain functionality during the life cycle of the component. 
//useEffect() combines componentDidMount, componentDidUpdate, and componentWillUnmount life cycle into a single api.

//Lifecycle methods are:

// componentDidMount      ----   Component is created and inserted into the DOM.

// Update                  ----   After the component mounts and renders into the DOM.component 
//                               then updates when we have an update in our props or state.
//.... shouldComponentUpdate
//                        ----   Return a boolean to determine if React should update the component. 
//                               The default value for this method is true
//                               This method is what tells React whether the component will update or skip.
//.... componentDidUpdate
//                        ----   This method is invoked after the component updates. 
//                               It compares if a specific prop or state changed.

//componentWillUnmount    ----   Responsible for the cleanup in our DOM, 
//                               especially when we want to remove a component from the DOM,
//                               in React, this is called unmounting.



let UseEffectHook = () => {
    const [count, setCount] = useState(1);
    const [calculation, setCalculation] = useState(0);
    
//componentDidMount

//   useEffect(() => {
//    console.log(" Inside this callback function we perform our side effects...componentDidMount");
//     setCount(count + 1);
//   });

//componentDidUpdate
//   useEffect(() => {
//   console.log("Inside this callback function we perform our side effects...componentDidUpdate");
//     setCount(count + 1);
//   },[]);

//componentDidUpdate
//   useEffect(() => {
//     console.log("Inside this callback function we perform our side effects...componentDidUpdate");
//     setCalculation(()=> count * 2);
//   }, [count]);


//componentWillUnmount
useEffect(() => {
    console.log("Inside this callback function we perform our side effects...componentWillUnmount");
    setCalculation(()=> count * 2);
    return ()=> {
    setCalculation(()=> count * 2);
    }
  }, []);

  return (
    <>
      <div className="text-3xl font-bold py-6">Example of useEffect Hook</div>
      <div className="flex flex-col items-center justify-center ">
        <div className=" w-48 border-2 p-4 m-4">
        <div className=" bg-sky-500 m-4 p-4 text-white">{count}</div>
          <div className=" bg-sky-500 m-4 p-4 text-white">{calculation}</div>
          <div className="flex flex-row items-center justify-center">
            <button
              className={`flex flex-col items-center justify-center p-4 h-12 w-32 border-2 rounded-lg bg-black text-white my-4`}
              onClick={() => {
                setCount(count + 1);
              }}
            >
              Click me
            </button>
          </div>
        </div>
      </div>
    </>
  );
};

export default UseEffectHook;
