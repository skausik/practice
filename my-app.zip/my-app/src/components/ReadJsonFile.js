import React, { useState } from "react";

let value="Kausik";
function onMyClick() {
    
} 


const Abc=({myClick})=>{
    return(<><button onClick={()=>{myClick(value)}}>Hii</button></>)
}


const ReadJsonFile = () => {
    let [ab, setAb]=useState();
  const url = "https://dummyjson.com/products/1";
  const fetchApi = (url) => {
    fetch(url)
      .then((res) => res.json())
      .then((json) => console.log(json))
      .catch((err) => console.log(err));
  };

  const cardss = (art) => {
    console.log("You can read about this massacre at: " + art);
}
console.log(ab);
  return (
    <>
      {/* <button onClick={() => {fetchApi(url)}}>FetchAPIClick */}
      <Abc myClick={cardss}/>
      {/* </button> */}
    </>
  );
};

export default ReadJsonFile;
