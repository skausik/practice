import React, { useState } from "react";

let JScodePractice_x = () => {
  const [count, setCount] = useState(0);
  const [buttonColorChange, setButtoncolorChange] = useState("blue-900");
  return (
    <>
      <div className="flex    bg-sky-500 text-black font bold border">
        <div className="m-4 flex flex-row items-center justify-center w-40 h-44 border border-black bg-white">
          {count}
        </div>
        <div className="m-4 flex flex-row items-center justify-center w-40 h-44 border border-black bg-white">
          HII
        </div>
        <div className="m-4 flex flex-row items-center justify-center w-40 h-44 border border-black bg-white">
          HII
        </div>
        <div className="m-4 flex flex-row items-center justify-center w-40 h-44 border border-black bg-white">
          HII
        </div>
        <div className="flex  items-center justify-end">
          <button
            className={`flex flex-row items-center justify-center p-4 h-12 w-28 border-2 rounded-lg bg-${buttonColorChange}`}
            onClick={() => {
              setButtoncolorChange("white");
              setCount(count + 1);
            }}
          >
            Click me
          </button>
        </div>
      </div>
    </>
  );
};

const users = [
  { name: "John Doe", id: 1 },
  { name: "Jane Doe", id: 2 },
  { name: "Billy Doe", id: 3 },
];

let JScodePractice = () => {
  var input=12;
  var result='\n'
    for(var i=1;i<=input;i++){
      for(var j=1;j<10;j++){

        result +=  (i*j) + ' ';
      }
      result += '\n';

    }
  console.log(`Table of 1 to ${input}` ,result);

  var arr = [12, 10, 12, 10, 6, 50, 100, 1000];

  var sum = arr.reduce((x,y)=>x+y);
  console.log("sum",sum);
  console.log("sort", arr.sort((a,b)=>a-b));

  var inputString="aaaa bbbb ccccc vvvv";

  var newString=inputString.split(' ').join("");
  console.log("newString",newString);

  var number = "yfhfg";

   console.log( number%10==0?true:false);
  console.log(typeof arr);

  var isArray=(input)=>{
  if(toString.call(input)=="[object Array]"){
    return true;

  }
  return false;
  }
  console.log("Array",isArray(number));

  var lastElem=(input,n)=>{
    if(input==null)
    return 0;
    if(n==null)
    return input[input.length-1];
    else return input.slice(Math.max(input.length-n,0));
  }
  console.log("last", lastElem(arr,3));

  var myColor = ["Red", "Green", "White", "Black"];

  console.log("new", myColor.join("+"));

  var input = 4545785;
    var numberString=input.toString();
    console.log("numberString",numberString);
    var result=[numberString[0]];
  for(let i=1;i<numberString.length;i++){
    if((numberString[i-1]%2 === 0)&&(numberString[i]%2 === 0)){
      console.log("aaa");
    result.push('-',numberString[i]);
    }
    else {result.push(numberString[i]);}
  }
  var final= result.join('');

  console.log("func",final);

  var arr1 = [ -3, 8, 7, 6, 5, -4, 3, 2, 1 ];
  console.log("sort",arr1.sort((a,b)=>a-b));

  const num=window.prompt();
  console.log("num",typeof num);
  const str = num.toString();
  const result = [str[0]];

  for(let x=1; x<str.length; x++)
    {
      if((str[x-1]%2 === 0)&&(str[x]%2 === 0))
       {
        result.push('-', str[x]);
       }
      else
       {
        result.push(str[x]);
       }
    }
  console.log(result.join(''));

  var arr1=[3, 'a', 'a', 'a','b','b','b', 2, 3, 'a', 3, 'a', 2, 4, 9, 3];
  var m=0;
  var mf=1;
  var item;
  for(let i=0;i<arr1.length;i++){
    for(let j=i;j<arr1.length;j++){
      if(arr1[i] == arr1[j]){
       m++;
      }
      if(mf<m){
        mf=m;
        item= arr1[i];
      }
    }
    m=0;
  }
  console.log(`${item} ( ${mf} times ) `) ;

  (function(){
    var x=10;
   ( function(){
      var x=20;
      (function(){
        console.log(x);
        var x=30;
      })();
    })();
  })();

  var inputStr = "kausiksantra";

  var charArr = inputStr.split("");
  var count = 0;
var keys=[];
var values=[];

  var unique = [...new Set(charArr)];
const obj=[];
  for (let i = 0; i < unique.length; i++) {
    for (let j = i; j < charArr.length; j++) {
      if (unique[i] === charArr[j]) {
        count++;
      }
    }
    keys.push(unique[i]);
    values.push(count);


    var value = `${unique[i]} count is ${count}`;
    console.log("value",value);
    count = 0;
  }
  for(let i=0;i<keys.length;i++){
    obj[keys[i]]=values[i];
  }
  console.log("obj",obj);
 var lll=keys.filter((item,index)=>
 values.indexOf(
  Math.max.apply(null,values)) === index
  
  );
console.log("lll",values.indexOf(
  Math.max.apply(null,values)));





  function getFrequency(string) {
    var freq = {};
    for (var i=0; i<string.length;i++) {
        var character = string.charAt(i);
        console.log("character",character);
        if (freq[character]) {
           freq[character]++;
        } else {
           freq[character] = 1;
        }
    }

    return freq;
};

console.log("getFrequency",getFrequency("kausiksantra"));


let A=()=>{
const abc=()=>{
  console.log("abc called");
}



  return(<><B func={abc}/></>);
}

// const arr = [1,2,[3,4],[5,6]];

// const arr = [{}, {id: 1}, {}, {id: 2}, {}];

const B=(props)=>{
  return(<>
  <button onClick={()=>{props.func()}}>Ok</button>
  </>)
}

 var a=7;
 var b=6;
 var c=5;

 if(false){
  return <h1>Hii {"(a+b)-c"}</h1>;
 }
 

}


export default JScodePractice;
