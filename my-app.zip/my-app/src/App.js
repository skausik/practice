
import './App.css';
import Index from './components';
//import ReactRedux from './components/reduxExample/reactRedux';

function App() {
  return (
    <div className="App">
      <Index/>
      {/* <ReactRedux/> */}
    </div>
  );
}

export default App;
